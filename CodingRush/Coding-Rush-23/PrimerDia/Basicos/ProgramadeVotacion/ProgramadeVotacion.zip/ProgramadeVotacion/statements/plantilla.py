# Pedir al usuario su nombre y año de nacimiento
nombre = 
año_nacimiento = 

# Calcular la edad y el número de años que ha sido elegible para votar
edad = 

# ¿Qué condicional debemos usar para cada mensaje?
if < :
    print("¡" + nombre + ", aún no tienes edad para votar. ¡Por favor, vuelve en " +  +  " años!")
elif == :
    print("¡" + nombre + ", tienes suficientes años de edad para votar!)
else:
    años_elegible = 
    print("¡" + nombre + ", tienes suficientes años de edad para votar y has sido elegible durante " + + " años!")
