num1 = int(input())

#¿Cómo serán los demás?
num2 = 
num3 = 
num4 = 

#¿Cómo calculamos el promedio?
promedio = 

#¿Qué condición usamos para decidir si pasaste o no?
if  < :
    print("No pasaste, tu promedio es: " + promedio)
else:
    print("Pasaste, tu promedio es: " + promedio) 