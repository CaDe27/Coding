precio1 =
precio2 =

if ...:
  print(...)
else:
  print(...)