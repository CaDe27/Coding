L = 
N = 

numeroTaza = 
cafeinaAcumulada = 

while  :


print()