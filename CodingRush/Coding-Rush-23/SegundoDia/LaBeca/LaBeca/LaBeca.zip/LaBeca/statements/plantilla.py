suma = 0
for i in range(5):
    C = 
    suma = 

promedio =  / 5
print(promedio)

if :
    print ("SI")
else:
    print ("NO")
    
    