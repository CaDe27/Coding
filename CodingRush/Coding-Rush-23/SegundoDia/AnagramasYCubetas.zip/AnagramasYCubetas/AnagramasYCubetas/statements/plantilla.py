n=int(input())

for i in range():
  cadena1=
  cadena2=
  ocurrenciasDigito=[0]*10
  for elem in cadena1:
    
  for elem in cadena2: