n = 

productos =['Muffin', 'Brownie', 'Dona', 'Galleta', 'Pastel']
# Tenemos que definir el tamaño de la lista
cant = [0]*5

# ¿Cuántas iteraciones necesitamos?
for i in range():
	# ¿Cómo guardamos las entradas?
	producto = 
	index = productos.index(producto)
	#aumentamos la cantidad
	cant[index] 

m = int(input())

# ¿Cuántas iteraciones necesitamos?
for e in range():
	# ¿Cómo guradamos las entradas?
	cat = 
	index2 = productos.index(cat)

	# ¿Cómo verificamos si la clasificación existe en la lista?
	if cant[index2] :
		print("Bon appetit")
		# Tenemos que quitar la compra
		cant[index2] 
	else:
		print("No disponible")