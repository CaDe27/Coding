n = int(input())

# ¿En dónde guardaremos la lista de palabras?
palabras = 
# ¿Cuántas veces pediremos palabras?
for i in range():
    palabra = input()
    # ¿Cómo añadirás a la lista de palabras?
    palabras.

letra = input()

for palabra in palabras:
    # ¿Qué quieres revisar de cada palabra?