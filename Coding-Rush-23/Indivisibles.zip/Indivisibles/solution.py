digitos = int(input())
num = "9"*(digitos - 1) + "8"
print(num)