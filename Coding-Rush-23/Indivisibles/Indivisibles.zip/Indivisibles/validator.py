respConcursante = int(input())
if respConcursante%15 != 0:
    score = 1
else:
    score = 0
print(score)